# Keep Android for Cars App Library service and session entry points
-keep class com.autohub.app.automotive.AutoHubCarAppService { *; }
-keep class com.autohub.app.automotive.AutoHubCarSession { *; }
-keep class androidx.car.app.** { *; }

# Keep Media3 session and notification listener service
-keep class com.autohub.app.media.AutoHubMediaLibraryService { *; }
-keep class com.autohub.app.media.AutoHubNotificationListenerService { *; }

# Keep Compose and Kotlin Coroutines metadata minimal
-dontwarn java.lang.invoke.StringConcatFactory
