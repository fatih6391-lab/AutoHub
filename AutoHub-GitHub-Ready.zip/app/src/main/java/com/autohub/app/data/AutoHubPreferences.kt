package com.autohub.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.autoHubDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "autohub_preferences"
)

enum class AutoHubThemeMode(val displayName: String) {
    OBSIDIAN_CYAN("Obsidian Cyan"),
    MIDNIGHT_COBALT("Midnight Cobalt"),
    PURE_OLED("Pure OLED Black")
}

data class UserSettings(
    val themeMode: AutoHubThemeMode = AutoHubThemeMode.OBSIDIAN_CYAN,
    val use24HourClock: Boolean = true,
    val showWeatherCard: Boolean = true,
    val showFavoritesStrip: Boolean = true,
    val compactLauncherGrid: Boolean = false,
    val reduceAnimations: Boolean = false,
    val offlineModeOnly: Boolean = false,
    val weatherCity: String = "San Francisco",
    val weatherLatitude: Double = 37.7749,
    val weatherLongitude: Double = -122.4194,
    val useCelsius: Boolean = true,
    val favoritePackages: Set<String> = emptySet()
)

class AutoHubPreferences(context: Context) {

    private val dataStore = context.applicationContext.autoHubDataStore

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val USE_24H_CLOCK = booleanPreferencesKey("use_24h_clock")
        val SHOW_WEATHER = booleanPreferencesKey("show_weather_card")
        val SHOW_FAVORITES = booleanPreferencesKey("show_favorites_strip")
        val COMPACT_GRID = booleanPreferencesKey("compact_launcher_grid")
        val REDUCE_ANIMATIONS = booleanPreferencesKey("reduce_animations")
        val OFFLINE_ONLY = booleanPreferencesKey("offline_mode_only")
        val WEATHER_CITY = stringPreferencesKey("weather_city")
        val WEATHER_LAT = stringPreferencesKey("weather_lat")
        val WEATHER_LON = stringPreferencesKey("weather_lon")
        val USE_CELSIUS = booleanPreferencesKey("use_celsius")
        val FAVORITE_PACKAGES = stringSetPreferencesKey("favorite_packages")
    }

    val settingsFlow: Flow<UserSettings> = dataStore.data
        .catch { exception ->
            if (exception is IOException) emit(emptyPreferences()) else throw exception
        }
        .map { prefs ->
            val themeName = prefs[Keys.THEME_MODE] ?: AutoHubThemeMode.OBSIDIAN_CYAN.name
            val themeMode = AutoHubThemeMode.entries.firstOrNull { it.name == themeName }
                ?: AutoHubThemeMode.OBSIDIAN_CYAN

            UserSettings(
                themeMode = themeMode,
                use24HourClock = prefs[Keys.USE_24H_CLOCK] ?: true,
                showWeatherCard = prefs[Keys.SHOW_WEATHER] ?: true,
                showFavoritesStrip = prefs[Keys.SHOW_FAVORITES] ?: true,
                compactLauncherGrid = prefs[Keys.COMPACT_GRID] ?: false,
                reduceAnimations = prefs[Keys.REDUCE_ANIMATIONS] ?: false,
                offlineModeOnly = prefs[Keys.OFFLINE_ONLY] ?: false,
                weatherCity = prefs[Keys.WEATHER_CITY] ?: "San Francisco",
                weatherLatitude = prefs[Keys.WEATHER_LAT]?.toDoubleOrNull() ?: 37.7749,
                weatherLongitude = prefs[Keys.WEATHER_LON]?.toDoubleOrNull() ?: -122.4194,
                useCelsius = prefs[Keys.USE_CELSIUS] ?: true,
                favoritePackages = prefs[Keys.FAVORITE_PACKAGES] ?: emptySet()
            )
        }

    suspend fun setThemeMode(mode: AutoHubThemeMode) {
        dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setUse24HourClock(enabled: Boolean) {
        dataStore.edit { it[Keys.USE_24H_CLOCK] = enabled }
    }

    suspend fun setShowWeatherCard(enabled: Boolean) {
        dataStore.edit { it[Keys.SHOW_WEATHER] = enabled }
    }

    suspend fun setShowFavoritesStrip(enabled: Boolean) {
        dataStore.edit { it[Keys.SHOW_FAVORITES] = enabled }
    }

    suspend fun setCompactLauncherGrid(enabled: Boolean) {
        dataStore.edit { it[Keys.COMPACT_GRID] = enabled }
    }

    suspend fun setReduceAnimations(enabled: Boolean) {
        dataStore.edit { it[Keys.REDUCE_ANIMATIONS] = enabled }
    }

    suspend fun setOfflineModeOnly(enabled: Boolean) {
        dataStore.edit { it[Keys.OFFLINE_ONLY] = enabled }
    }

    suspend fun setUseCelsius(enabled: Boolean) {
        dataStore.edit { it[Keys.USE_CELSIUS] = enabled }
    }

    suspend fun setWeatherLocation(city: String, lat: Double, lon: Double) {
        dataStore.edit {
            it[Keys.WEATHER_CITY] = city
            it[Keys.WEATHER_LAT] = lat.toString()
            it[Keys.WEATHER_LON] = lon.toString()
        }
    }

    suspend fun toggleFavorite(packageName: String) {
        dataStore.edit { prefs ->
            val current = prefs[Keys.FAVORITE_PACKAGES] ?: emptySet()
            prefs[Keys.FAVORITE_PACKAGES] = if (packageName in current) {
                current - packageName
            } else {
                current + packageName
            }
        }
    }
}
