package com.autohub.app.core

import android.content.Context
import androidx.car.app.connection.CarConnection
import androidx.lifecycle.Observer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flowOn

enum class VehicleConnectionStatus(val label: String) {
    DISCONNECTED("Phone Standalone"),
    ANDROID_AUTO_PROJECTED("Android Auto Connected"),
    AUTOMOTIVE_OS_NATIVE("Android Automotive OS")
}

/**
 * Observes the official androidx.car.app.connection.CarConnection API safely.
 * Never crashes on phones without Android Auto installed.
 */
class CarConnectionMonitor(context: Context) {

    private val appContext = context.applicationContext

    val connectionStatusFlow: Flow<VehicleConnectionStatus> = callbackFlow {
        trySend(VehicleConnectionStatus.DISCONNECTED)

        val liveData = runCatching { CarConnection(appContext).type }.getOrNull()
        if (liveData == null) {
            close()
            return@callbackFlow
        }

        val observer = Observer<Int> { connectionType ->
            val mapped = when (connectionType) {
                CarConnection.CONNECTION_TYPE_PROJECTION -> VehicleConnectionStatus.ANDROID_AUTO_PROJECTED
                CarConnection.CONNECTION_TYPE_NATIVE -> VehicleConnectionStatus.AUTOMOTIVE_OS_NATIVE
                else -> VehicleConnectionStatus.DISCONNECTED
            }
            trySend(mapped)
        }

        liveData.observeForever(observer)

        awaitClose {
            liveData.removeObserver(observer)
        }
    }.flowOn(Dispatchers.Main.immediate).distinctUntilChanged()
}
