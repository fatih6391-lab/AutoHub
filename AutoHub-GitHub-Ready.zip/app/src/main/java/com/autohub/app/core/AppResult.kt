package com.autohub.app.core

/**
 * Lightweight sealed result wrapper for deterministic error handling
 * without exception-driven control flow across repositories and UI.
 */
sealed interface AppResult<out T> {
    data class Success<T>(val data: T) : AppResult<T>
    data class Error(val message: String, val cause: Throwable? = null) : AppResult<Nothing>
}
