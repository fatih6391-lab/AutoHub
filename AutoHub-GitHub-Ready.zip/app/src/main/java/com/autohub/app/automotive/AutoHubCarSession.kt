package com.autohub.app.automotive

import android.content.Intent
import androidx.car.app.Screen
import androidx.car.app.Session

/**
 * Official Car App Library Session hosting the projected head-unit screen stack.
 */
class AutoHubCarSession : Session() {
    override fun onCreateScreen(intent: Intent): Screen {
        return DashboardCarScreen(carContext)
    }
}
