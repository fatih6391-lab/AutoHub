package com.autohub.app.media

import android.service.notification.NotificationListenerService

/**
 * Minimal opt-in NotificationListenerService required by Android's MediaSessionManager
 * so the native phone dashboard can display current track title and artist from other
 * media players without polling or reading personal notification content.
 */
class AutoHubNotificationListenerService : NotificationListenerService()
