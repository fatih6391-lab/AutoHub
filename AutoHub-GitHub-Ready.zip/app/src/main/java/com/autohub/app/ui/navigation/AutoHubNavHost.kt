package com.autohub.app.ui.navigation

import android.content.res.Configuration
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.MusicNote
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.autohub.app.app.AutoHubApplication
import com.autohub.app.core.AppResult
import com.autohub.app.core.IntentLauncher
import com.autohub.app.dashboard.DashboardScreen
import com.autohub.app.dashboard.DashboardViewModel
import com.autohub.app.entertainment.EntertainmentScreen
import com.autohub.app.launcher.LauncherScreen
import com.autohub.app.launcher.LauncherViewModel
import com.autohub.app.media.MusicScreen
import com.autohub.app.settings.SettingsScreen
import com.autohub.app.settings.SettingsViewModel
import com.autohub.app.ui.theme.LocalAutoHubPalette
import kotlinx.coroutines.launch

enum class AutoHubDestination(val route: String, val label: String, val icon: ImageVector) {
    DASHBOARD("dashboard", "Home", Icons.Outlined.Dashboard),
    LAUNCHER("launcher", "Apps", Icons.Outlined.Apps),
    MUSIC("music", "Music", Icons.Outlined.MusicNote),
    ENTERTAINMENT("entertainment", "Parked", Icons.Outlined.PlayCircle),
    SETTINGS("settings", "Settings", Icons.Outlined.Settings)
}

@Composable
fun AutoHubNavHost(app: AutoHubApplication) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: AutoHubDestination.DASHBOARD.route

    val configuration = LocalConfiguration.current
    val useNavigationRail = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE ||
        configuration.screenWidthDp >= 720

    val palette = LocalAutoHubPalette.current
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    val dashboardViewModel: DashboardViewModel = viewModel(
        factory = DashboardViewModel.factory(
            preferences = app.preferences,
            weatherRepository = app.weatherRepository,
            connectivityObserver = app.connectivityObserver,
            carConnectionMonitor = app.carConnectionMonitor,
            appRepository = app.appRepository,
            activeMediaManager = app.activeMediaManager
        )
    )
    val launcherViewModel: LauncherViewModel = viewModel(
        factory = LauncherViewModel.factory(
            appRepository = app.appRepository,
            preferences = app.preferences
        )
    )
    val settingsViewModel: SettingsViewModel = viewModel(
        factory = SettingsViewModel.factory(
            preferences = app.preferences,
            iconCache = app.iconCache
        )
    )

    val dashboardState by dashboardViewModel.uiState.collectAsStateWithLifecycle()
    val launcherState by launcherViewModel.uiState.collectAsStateWithLifecycle()
    val settingsState by settingsViewModel.settings.collectAsStateWithLifecycle()

    fun showErrorIfAny(result: AppResult<Unit>) {
        if (result is AppResult.Error) {
            coroutineScope.launch { snackbarHostState.showSnackbar(result.message) }
        }
    }

    fun navigateTo(route: String) {
        navController.navigate(route) {
            popUpTo(AutoHubDestination.DASHBOARD.route) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        containerColor = palette.canvas,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        bottomBar = {
            if (!useNavigationRail) {
                NavigationBar(containerColor = palette.surface) {
                    AutoHubDestination.entries.forEach { dest ->
                        NavigationBarItem(
                            selected = currentRoute == dest.route,
                            onClick = { navigateTo(dest.route) },
                            icon = { Icon(dest.icon, contentDescription = dest.label) },
                            label = { Text(dest.label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = palette.primaryAccent,
                                selectedTextColor = palette.primaryAccent,
                                unselectedIconColor = palette.textMuted,
                                unselectedTextColor = palette.textMuted,
                                indicatorColor = palette.surfaceElevated
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .background(palette.canvas)
                .padding(innerPadding)
        ) {
            if (useNavigationRail) {
                NavigationRail(
                    containerColor = palette.surface,
                    modifier = Modifier.fillMaxHeight()
                ) {
                    AutoHubDestination.entries.forEach { dest ->
                        NavigationRailItem(
                            selected = currentRoute == dest.route,
                            onClick = { navigateTo(dest.route) },
                            icon = { Icon(dest.icon, contentDescription = dest.label) },
                            label = { Text(dest.label) },
                            colors = NavigationRailItemDefaults.colors(
                                selectedIconColor = palette.primaryAccent,
                                selectedTextColor = palette.primaryAccent,
                                unselectedIconColor = palette.textMuted,
                                unselectedTextColor = palette.textMuted,
                                indicatorColor = palette.surfaceElevated
                            )
                        )
                    }
                }
            }

            Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                NavHost(
                    navController = navController,
                    startDestination = AutoHubDestination.DASHBOARD.route
                ) {
                    composable(AutoHubDestination.DASHBOARD.route) {
                        DashboardScreen(
                            uiState = dashboardState,
                            iconCache = app.iconCache,
                            onLoadWeather = dashboardViewModel::loadWeatherOnDemand,
                            onNavigateQuery = { q -> showErrorIfAny(IntentLauncher.launchNavigationQuery(context, q)) },
                            onPlayPause = dashboardViewModel::togglePlayPause,
                            onSkipNext = dashboardViewModel::skipNext,
                            onSkipPrevious = dashboardViewModel::skipPrevious,
                            onLaunchApp = { pkg -> showErrorIfAny(IntentLauncher.launchInstalledApp(context, pkg)) },
                            onOpenLauncher = { navigateTo(AutoHubDestination.LAUNCHER.route) },
                            onOpenSettings = { navigateTo(AutoHubDestination.SETTINGS.route) }
                        )
                    }

                    composable(AutoHubDestination.LAUNCHER.route) {
                        LauncherScreen(
                            uiState = launcherState,
                            compactGrid = settingsState.compactLauncherGrid,
                            iconCache = app.iconCache,
                            onSearchChange = launcherViewModel::updateSearchQuery,
                            onFavoritesOnlyChange = launcherViewModel::setFavoritesOnly,
                            onToggleFavorite = launcherViewModel::toggleFavorite,
                            onLaunchApp = { pkg -> showErrorIfAny(IntentLauncher.launchInstalledApp(context, pkg)) },
                            onRefresh = launcherViewModel::refreshInstalledApps
                        )
                    }

                    composable(AutoHubDestination.MUSIC.route) {
                        MusicScreen(
                            playbackState = dashboardState.media,
                            onPlayPause = dashboardViewModel::togglePlayPause,
                            onSkipNext = dashboardViewModel::skipNext,
                            onSkipPrevious = dashboardViewModel::skipPrevious,
                            onRequestNotificationAccess = {
                                showErrorIfAny(IntentLauncher.openNotificationListenerSettings(context))
                            }
                        )
                    }

                    composable(AutoHubDestination.ENTERTAINMENT.route) {
                        EntertainmentScreen(
                            vehicleStatus = dashboardState.vehicleStatus,
                            onOpenYouTube = { query ->
                                showErrorIfAny(IntentLauncher.launchOfficialYouTube(context, query))
                            }
                        )
                    }

                    composable(AutoHubDestination.SETTINGS.route) {
                        SettingsScreen(
                            settings = settingsState,
                            onSelectTheme = settingsViewModel::setThemeMode,
                            onToggle24h = settingsViewModel::setUse24HourClock,
                            onToggleWeather = settingsViewModel::setShowWeatherCard,
                            onToggleFavorites = settingsViewModel::setShowFavoritesStrip,
                            onToggleCompactGrid = settingsViewModel::setCompactLauncherGrid,
                            onToggleReduceAnimations = settingsViewModel::setReduceAnimations,
                            onToggleOfflineOnly = settingsViewModel::setOfflineModeOnly,
                            onToggleCelsius = settingsViewModel::setUseCelsius,
                            onClearIconCache = {
                                settingsViewModel.clearIconCache()
                                coroutineScope.launch { snackbarHostState.showSnackbar("App icon cache cleared.") }
                            },
                            onOpenFavoritesManager = { navigateTo(AutoHubDestination.LAUNCHER.route) }
                        )
                    }
                }
            }
        }
    }
}
