package com.autohub.app.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.autohub.app.BuildConfig
import com.autohub.app.data.AutoHubThemeMode
import com.autohub.app.data.UserSettings
import com.autohub.app.ui.components.AutomotiveCard
import com.autohub.app.ui.theme.LocalAutoHubPalette

@Composable
fun SettingsScreen(
    settings: UserSettings,
    onSelectTheme: (AutoHubThemeMode) -> Unit,
    onToggle24h: (Boolean) -> Unit,
    onToggleWeather: (Boolean) -> Unit,
    onToggleFavorites: (Boolean) -> Unit,
    onToggleCompactGrid: (Boolean) -> Unit,
    onToggleReduceAnimations: (Boolean) -> Unit,
    onToggleOfflineOnly: (Boolean) -> Unit,
    onToggleCelsius: (Boolean) -> Unit,
    onClearIconCache: () -> Unit,
    onOpenFavoritesManager: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalAutoHubPalette.current

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Settings",
            style = MaterialTheme.typography.headlineMedium,
            color = palette.textPrimary
        )

        // Theme Selection
        AutomotiveCard(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "Appearance & Theme",
                style = MaterialTheme.typography.titleMedium,
                color = palette.textPrimary
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AutoHubThemeMode.entries.forEach { mode ->
                    val selected = settings.themeMode == mode
                    Surface(
                        onClick = { onSelectTheme(mode) },
                        shape = RoundedCornerShape(12.dp),
                        color = if (selected) palette.primaryAccent else palette.surfaceElevated,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = mode.displayName,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (selected) palette.canvas else palette.textPrimary,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 12.dp)
                        )
                    }
                }
            }
        }

        // Dashboard Customization
        AutomotiveCard(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "Dashboard Customization",
                style = MaterialTheme.typography.titleMedium,
                color = palette.textPrimary
            )
            Spacer(modifier = Modifier.height(8.dp))
            SettingsToggleRow(
                title = "24-Hour Digital Clock",
                subtitle = "Use 24-hour tabular time format on dashboard",
                checked = settings.use24HourClock,
                onCheckedChange = onToggle24h
            )
            HorizontalDivider(color = palette.border)
            SettingsToggleRow(
                title = "Show Weather Card",
                subtitle = "Displays weather slot (loads strictly on demand)",
                checked = settings.showWeatherCard,
                onCheckedChange = onToggleWeather
            )
            HorizontalDivider(color = palette.border)
            SettingsToggleRow(
                title = "Temperature in Celsius (°C)",
                subtitle = "Disable to display Fahrenheit (°F)",
                checked = settings.useCelsius,
                onCheckedChange = onToggleCelsius
            )
            HorizontalDivider(color = palette.border)
            SettingsToggleRow(
                title = "Show Favorite Apps Strip",
                subtitle = "Quick phone shortcuts pinned on the dashboard",
                checked = settings.showFavoritesStrip,
                onCheckedChange = onToggleFavorites
            )
            HorizontalDivider(color = palette.border)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onOpenFavoritesManager)
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Manage Favorite Applications",
                        style = MaterialTheme.typography.bodyMedium,
                        color = palette.textPrimary
                    )
                    Text(
                        text = "${settings.favoritePackages.size} pinned apps",
                        style = MaterialTheme.typography.labelMedium,
                        color = palette.textMuted
                    )
                }
                Text(
                    text = "Edit",
                    style = MaterialTheme.typography.labelMedium,
                    color = palette.primaryAccent
                )
            }
        }

        // Performance & Memory
        AutomotiveCard(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "Performance & Efficiency",
                style = MaterialTheme.typography.titleMedium,
                color = palette.textPrimary
            )
            Spacer(modifier = Modifier.height(8.dp))
            SettingsToggleRow(
                title = "Reduce Animations",
                subtitle = "Minimizes transition effects on low-end GPUs",
                checked = settings.reduceAnimations,
                onCheckedChange = onToggleReduceAnimations
            )
            HorizontalDivider(color = palette.border)
            SettingsToggleRow(
                title = "Compact Launcher Grid",
                subtitle = "Fit more app tiles per row on wide displays",
                checked = settings.compactLauncherGrid,
                onCheckedChange = onToggleCompactGrid
            )
            HorizontalDivider(color = palette.border)
            SettingsToggleRow(
                title = "Strict Offline Mode",
                subtitle = "Disables all optional network calls including weather",
                checked = settings.offlineModeOnly,
                onCheckedChange = onToggleOfflineOnly
            )
            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = onClearIconCache,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = palette.surfaceElevated,
                    contentColor = palette.textPrimary
                )
            ) {
                Text("Clear Cached App Icons")
            }
        }

        // About AutoHub
        AutomotiveCard(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "About AutoHub",
                style = MaterialTheme.typography.titleMedium,
                color = palette.textPrimary
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Version ${BuildConfig.VERSION_NAME} · Minimum Android 10 (API 29)",
                style = MaterialTheme.typography.labelMedium,
                color = palette.primaryAccent
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "AutoHub combines a lightweight native phone automotive dashboard with " +
                    "an officially compliant Android for Cars App Library companion and Media3 service. " +
                    "It does not replace the Android Auto system launcher, includes zero ads or trackers, " +
                    "and keeps video playback strictly restricted to parked phone use.",
                style = MaterialTheme.typography.bodyMedium,
                color = palette.textSecondary
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
private fun SettingsToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    val palette = LocalAutoHubPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                color = palette.textPrimary
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelMedium,
                color = palette.textMuted
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = palette.canvas,
                checkedTrackColor = palette.primaryAccent,
                uncheckedThumbColor = palette.textMuted,
                uncheckedTrackColor = palette.surfaceElevated
            )
        )
    }
}
