package com.autohub.app.automotive

import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.MessageTemplate
import androidx.car.app.model.Template
import com.autohub.app.R

/**
 * Official MessageTemplate clearly documenting Android Auto safety compliance.
 */
class ComplianceInfoCarScreen(carContext: CarContext) : Screen(carContext) {

    override fun onGetTemplate(): Template {
        return MessageTemplate.Builder(
            "AutoHub uses official Android for Cars templates for safe driving. " +
                "Full phone app launcher and parked-only video entertainment remain strictly on your phone screen."
        )
            .setTitle(carContext.getString(R.string.car_compliance_title))
            .setHeaderAction(Action.BACK)
            .addAction(
                Action.Builder()
                    .setTitle("Back to Companion")
                    .setOnClickListener { screenManager.pop() }
                    .build()
            )
            .build()
    }
}
