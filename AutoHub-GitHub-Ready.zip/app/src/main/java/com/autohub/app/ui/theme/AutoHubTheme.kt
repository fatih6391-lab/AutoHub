package com.autohub.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.autohub.app.data.AutoHubThemeMode

@Immutable
data class AutoHubPalette(
    val canvas: Color,
    val surface: Color,
    val surfaceElevated: Color,
    val border: Color,
    val primaryAccent: Color,
    val secondaryAccent: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val positive: Color,
    val warning: Color,
    val danger: Color
)

private val ObsidianCyanPalette = AutoHubPalette(
    canvas = Color(0xFF07090D),
    surface = Color(0xFF10141C),
    surfaceElevated = Color(0xFF171D28),
    border = Color(0xFF232C3D),
    primaryAccent = Color(0xFF22D3EE),
    secondaryAccent = Color(0xFF3B82F6),
    textPrimary = Color(0xFFF8FAFC),
    textSecondary = Color(0xFFCBD5E1),
    textMuted = Color(0xFF8392A7),
    positive = Color(0xFF22C55E),
    warning = Color(0xFFF59E0B),
    danger = Color(0xFFEF4444)
)

private val MidnightCobaltPalette = AutoHubPalette(
    canvas = Color(0xFF060A14),
    surface = Color(0xFF0E1525),
    surfaceElevated = Color(0xFF152036),
    border = Color(0xFF223352),
    primaryAccent = Color(0xFF60A5FA),
    secondaryAccent = Color(0xFF38BDF8),
    textPrimary = Color(0xFFF8FAFC),
    textSecondary = Color(0xFFCBD5E1),
    textMuted = Color(0xFF8599B8),
    positive = Color(0xFF22C55E),
    warning = Color(0xFFF59E0B),
    danger = Color(0xFFEF4444)
)

private val PureOledPalette = AutoHubPalette(
    canvas = Color(0xFF000000),
    surface = Color(0xFF0B0E14),
    surfaceElevated = Color(0xFF131822),
    border = Color(0xFF1F2735),
    primaryAccent = Color(0xFF22D3EE),
    secondaryAccent = Color(0xFF2563EB),
    textPrimary = Color(0xFFFFFFFF),
    textSecondary = Color(0xFFD1D5DB),
    textMuted = Color(0xFF8A94A6),
    positive = Color(0xFF22C55E),
    warning = Color(0xFFF59E0B),
    danger = Color(0xFFEF4444)
)

val LocalAutoHubPalette = staticCompositionLocalOf { ObsidianCyanPalette }

private val AutoHubTypography = Typography(
    displayLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 56.sp,
        lineHeight = 60.sp,
        letterSpacing = (-1.5).sp,
        fontFeatureSettings = "tnum"
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 24.sp,
        lineHeight = 30.sp,
        letterSpacing = (-0.3).sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 17.sp,
        lineHeight = 22.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 22.sp
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.2.sp
    )
)

@Composable
fun AutoHubTheme(
    themeMode: AutoHubThemeMode,
    content: @Composable () -> Unit
) {
    val palette = when (themeMode) {
        AutoHubThemeMode.OBSIDIAN_CYAN -> ObsidianCyanPalette
        AutoHubThemeMode.MIDNIGHT_COBALT -> MidnightCobaltPalette
        AutoHubThemeMode.PURE_OLED -> PureOledPalette
    }

    val materialScheme = darkColorScheme(
        primary = palette.primaryAccent,
        secondary = palette.secondaryAccent,
        background = palette.canvas,
        surface = palette.surface,
        surfaceVariant = palette.surfaceElevated,
        outline = palette.border,
        onPrimary = Color(0xFF041016),
        onBackground = palette.textPrimary,
        onSurface = palette.textPrimary,
        onSurfaceVariant = palette.textSecondary
    )

    CompositionLocalProvider(LocalAutoHubPalette provides palette) {
        MaterialTheme(
            colorScheme = materialScheme,
            typography = AutoHubTypography,
            content = content
        )
    }
}
