package com.autohub.app.launcher

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.autohub.app.data.AutoHubPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class LauncherUiState(
    val apps: List<InstalledApp> = emptyList(),
    val searchQuery: String = "",
    val favoritesOnly: Boolean = false,
    val isLoading: Boolean = true
)

class LauncherViewModel(
    private val appRepository: AppRepository,
    private val preferences: AutoHubPreferences
) : ViewModel() {

    private val rawApps = MutableStateFlow<List<InstalledApp>>(emptyList())
    private val searchQuery = MutableStateFlow("")
    private val favoritesOnly = MutableStateFlow(false)
    private val isLoading = MutableStateFlow(true)

    val uiState: StateFlow<LauncherUiState> = combine(
        rawApps,
        preferences.settingsFlow,
        searchQuery,
        favoritesOnly,
        isLoading
    ) { installed, settings, query, favOnly, loading ->
        val updated = installed
            .map { app -> app.copy(isFavorite = app.packageName in settings.favoritePackages) }
            .filter { app ->
                val matchesFav = !favOnly || app.isFavorite
                val matchesQuery = query.isBlank() ||
                    app.label.contains(query.trim(), ignoreCase = true)
                matchesFav && matchesQuery
            }
            .sortedWith(
                compareByDescending<InstalledApp> { it.isFavorite }
                    .thenBy(String.CASE_INSENSITIVE_ORDER) { it.label }
            )

        LauncherUiState(
            apps = updated,
            searchQuery = query,
            favoritesOnly = favOnly,
            isLoading = loading
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = LauncherUiState()
    )

    init {
        refreshInstalledApps()
    }

    fun refreshInstalledApps() {
        viewModelScope.launch {
            isLoading.value = true
            rawApps.value = appRepository.loadLaunchableApps(emptySet())
            isLoading.value = false
        }
    }

    fun updateSearchQuery(query: String) {
        searchQuery.value = query
    }

    fun setFavoritesOnly(onlyFavorites: Boolean) {
        favoritesOnly.value = onlyFavorites
    }

    fun toggleFavorite(packageName: String) {
        viewModelScope.launch {
            preferences.toggleFavorite(packageName)
        }
    }

    companion object {
        fun factory(
            appRepository: AppRepository,
            preferences: AutoHubPreferences
        ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return LauncherViewModel(appRepository, preferences) as T
            }
        }
    }
}
