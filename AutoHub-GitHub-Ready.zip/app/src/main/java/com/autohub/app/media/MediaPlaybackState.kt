package com.autohub.app.media

data class MediaPlaybackState(
    val title: String = "No active playback",
    val artist: String = "Start a media app to control audio",
    val sourcePackage: String? = null,
    val isPlaying: Boolean = false,
    val hasMetadataAccess: Boolean = false
)
