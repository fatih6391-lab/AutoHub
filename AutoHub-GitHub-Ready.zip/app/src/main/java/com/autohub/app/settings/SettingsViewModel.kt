package com.autohub.app.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.autohub.app.data.AppIconCache
import com.autohub.app.data.AutoHubPreferences
import com.autohub.app.data.AutoHubThemeMode
import com.autohub.app.data.UserSettings
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val preferences: AutoHubPreferences,
    private val iconCache: AppIconCache
) : ViewModel() {

    val settings: StateFlow<UserSettings> = preferences.settingsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = UserSettings()
    )

    fun setThemeMode(mode: AutoHubThemeMode) {
        viewModelScope.launch { preferences.setThemeMode(mode) }
    }

    fun setUse24HourClock(enabled: Boolean) {
        viewModelScope.launch { preferences.setUse24HourClock(enabled) }
    }

    fun setShowWeatherCard(enabled: Boolean) {
        viewModelScope.launch { preferences.setShowWeatherCard(enabled) }
    }

    fun setShowFavoritesStrip(enabled: Boolean) {
        viewModelScope.launch { preferences.setShowFavoritesStrip(enabled) }
    }

    fun setCompactLauncherGrid(enabled: Boolean) {
        viewModelScope.launch { preferences.setCompactLauncherGrid(enabled) }
    }

    fun setReduceAnimations(enabled: Boolean) {
        viewModelScope.launch { preferences.setReduceAnimations(enabled) }
    }

    fun setOfflineModeOnly(enabled: Boolean) {
        viewModelScope.launch { preferences.setOfflineModeOnly(enabled) }
    }

    fun setUseCelsius(enabled: Boolean) {
        viewModelScope.launch { preferences.setUseCelsius(enabled) }
    }

    fun clearIconCache() {
        iconCache.clear()
    }

    companion object {
        fun factory(
            preferences: AutoHubPreferences,
            iconCache: AppIconCache
        ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return SettingsViewModel(preferences, iconCache) as T
            }
        }
    }
}
