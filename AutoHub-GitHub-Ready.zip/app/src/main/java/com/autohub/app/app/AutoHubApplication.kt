package com.autohub.app.app

import android.app.Application
import android.content.ComponentCallbacks2
import com.autohub.app.core.CarConnectionMonitor
import com.autohub.app.core.ConnectivityObserver
import com.autohub.app.data.AppIconCache
import com.autohub.app.data.AutoHubPreferences
import com.autohub.app.data.WeatherRepository
import com.autohub.app.launcher.AppRepository
import com.autohub.app.media.ActiveMediaManager

/**
 * Lightweight manual dependency container avoiding code-gen/DI startup overhead.
 * Releases cached bitmaps proactively under memory pressure.
 */
class AutoHubApplication : Application() {

    lateinit var preferences: AutoHubPreferences
        private set
    lateinit var weatherRepository: WeatherRepository
        private set
    lateinit var iconCache: AppIconCache
        private set
    lateinit var connectivityObserver: ConnectivityObserver
        private set
    lateinit var carConnectionMonitor: CarConnectionMonitor
        private set
    lateinit var appRepository: AppRepository
        private set
    lateinit var activeMediaManager: ActiveMediaManager
        private set

    override fun onCreate() {
        super.onCreate()
        preferences = AutoHubPreferences(this)
        weatherRepository = WeatherRepository()
        iconCache = AppIconCache()
        connectivityObserver = ConnectivityObserver(this)
        carConnectionMonitor = CarConnectionMonitor(this)
        appRepository = AppRepository(this)
        activeMediaManager = ActiveMediaManager(this)
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) {
            iconCache.clear()
        }
    }
}
