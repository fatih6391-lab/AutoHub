package com.autohub.app.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.autohub.app.data.UserSettings
import com.autohub.app.ui.navigation.AutoHubNavHost
import com.autohub.app.ui.theme.AutoHubTheme

class MainActivity : ComponentActivity() {

    private val autoHubApp: AutoHubApplication
        get() = application as AutoHubApplication

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )

        setContent {
            val settings by autoHubApp.preferences.settingsFlow
                .collectAsStateWithLifecycle(initialValue = UserSettings())

            AutoHubTheme(themeMode = settings.themeMode) {
                AutoHubNavHost(app = autoHubApp)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        autoHubApp.activeMediaManager.startObserving()
    }

    override fun onStop() {
        autoHubApp.activeMediaManager.stopObserving()
        super.onStop()
    }
}
