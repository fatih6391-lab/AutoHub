package com.autohub.app.core

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

/**
 * Safe Android intent launcher handling missing apps, disabled activities,
 * navigation geo: handoffs, and phone-only official YouTube launches without crashing.
 */
object IntentLauncher {

    private const val YOUTUBE_PACKAGE = "com.google.android.youtube"
    private const val YOUTUBE_WEB_URL = "https://m.youtube.com"

    fun launchInstalledApp(context: Context, packageName: String): AppResult<Unit> {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            ?: return AppResult.Error("Application is no longer installed or cannot be launched.")

        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            AppResult.Success(Unit)
        } catch (ex: ActivityNotFoundException) {
            AppResult.Error("Unable to open requested application.", ex)
        } catch (ex: SecurityException) {
            AppResult.Error("Launch blocked by system permissions.", ex)
        }
    }

    fun launchNavigationQuery(context: Context, query: String): AppResult<Unit> {
        val encoded = Uri.encode(query)
        val geoUri = Uri.parse("geo:0,0?q=$encoded")
        val mapIntent = Intent(Intent.ACTION_VIEW, geoUri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(mapIntent)
            AppResult.Success(Unit)
        } catch (ex: ActivityNotFoundException) {
            AppResult.Error("No compatible navigation app found on this device.", ex)
        }
    }

    /**
     * Legitimate phone-only launcher for official YouTube app or mobile web fallback.
     * Intended strictly for parked use on the phone screen; never projected to Android Auto.
     */
    fun launchOfficialYouTube(context: Context, searchOrUrl: String? = null): AppResult<Unit> {
        val targetUri = when {
            searchOrUrl.isNullOrBlank() -> Uri.parse(YOUTUBE_WEB_URL)
            searchOrUrl.startsWith("https://") -> Uri.parse(searchOrUrl)
            else -> Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(searchOrUrl)}")
        }

        val ytAppIntent = Intent(Intent.ACTION_VIEW, targetUri).apply {
            setPackage(YOUTUBE_PACKAGE)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        return try {
            context.startActivity(ytAppIntent)
            AppResult.Success(Unit)
        } catch (_: ActivityNotFoundException) {
            val browserIntent = Intent(Intent.ACTION_VIEW, targetUri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                context.startActivity(browserIntent)
                AppResult.Success(Unit)
            } catch (ex: ActivityNotFoundException) {
                AppResult.Error("Neither YouTube nor a web browser is available on this device.", ex)
            }
        }
    }

    fun openNotificationListenerSettings(context: Context): AppResult<Unit> {
        val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            AppResult.Success(Unit)
        } catch (ex: ActivityNotFoundException) {
            AppResult.Error("System notification access screen is unavailable.", ex)
        }
    }
}
