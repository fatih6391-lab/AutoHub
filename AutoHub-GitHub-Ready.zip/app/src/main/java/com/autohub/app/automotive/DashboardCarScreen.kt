package com.autohub.app.automotive

import androidx.car.app.CarContext
import androidx.car.app.CarToast
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.CarIcon
import androidx.car.app.model.GridItem
import androidx.car.app.model.GridTemplate
import androidx.car.app.model.ItemList
import androidx.car.app.model.Template
import androidx.core.graphics.drawable.IconCompat
import com.autohub.app.R
import com.autohub.app.app.AutoHubApplication

/**
 * Official Android Auto companion home screen built with GridTemplate.
 * Respects Android Auto template constraints, glanceable typography, and step limits.
 */
class DashboardCarScreen(carContext: CarContext) : Screen(carContext) {

    override fun onGetTemplate(): Template {
        val app = carContext.applicationContext as AutoHubApplication
        val mediaState = app.activeMediaManager.playbackState.value
        val weather = app.weatherRepository.getCachedSnapshot()

        val navIcon = CarIcon.Builder(
            IconCompat.createWithResource(carContext, R.drawable.ic_car_navigation)
        ).build()

        val mediaIcon = CarIcon.Builder(
            IconCompat.createWithResource(carContext, R.drawable.ic_car_media)
        ).build()

        val infoIcon = CarIcon.Builder(
            IconCompat.createWithResource(carContext, R.drawable.ic_car_info)
        ).build()

        val gridList = ItemList.Builder()
            .addItem(
                GridItem.Builder()
                    .setTitle("Navigation Shortcuts")
                    .setText("Home, Work & Stops")
                    .setImage(navIcon, GridItem.IMAGE_TYPE_ICON)
                    .setOnClickListener {
                        screenManager.push(NavigationShortcutsCarScreen(carContext))
                    }
                    .build()
            )
            .addItem(
                GridItem.Builder()
                    .setTitle(if (mediaState.isPlaying) "Pause Audio" else "Play Audio")
                    .setText(mediaState.title.take(22))
                    .setImage(mediaIcon, GridItem.IMAGE_TYPE_ICON)
                    .setOnClickListener {
                        app.activeMediaManager.togglePlayPause()
                        CarToast.makeText(carContext, "Toggled audio playback", CarToast.LENGTH_SHORT).show()
                        invalidate()
                    }
                    .build()
            )
            .addItem(
                GridItem.Builder()
                    .setTitle("Weather Status")
                    .setText(
                        weather?.let { "${it.formattedTemperature(true)} · ${it.conditionLabel}" }
                            ?: "Load on phone"
                    )
                    .setImage(infoIcon, GridItem.IMAGE_TYPE_ICON)
                    .setOnClickListener {
                        CarToast.makeText(
                            carContext,
                            weather?.let { "${it.city}: ${it.formattedTemperature(true)} (${it.conditionLabel})" }
                                ?: "Open AutoHub on phone to load weather on demand.",
                            CarToast.LENGTH_LONG
                        ).show()
                    }
                    .build()
            )
            .addItem(
                GridItem.Builder()
                    .setTitle("Safety & Compliance")
                    .setText("Android Auto Info")
                    .setImage(infoIcon, GridItem.IMAGE_TYPE_ICON)
                    .setOnClickListener {
                        screenManager.push(ComplianceInfoCarScreen(carContext))
                    }
                    .build()
            )
            .build()

        return GridTemplate.Builder()
            .setTitle(carContext.getString(R.string.car_dashboard_title))
            .setHeaderAction(Action.APP_ICON)
            .setSingleList(gridList)
            .build()
    }
}
