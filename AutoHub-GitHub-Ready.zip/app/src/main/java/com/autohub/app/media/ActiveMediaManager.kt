package com.autohub.app.media

import android.content.ComponentName
import android.content.Context
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock
import android.provider.Settings
import android.view.KeyEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Event-driven MediaSession controller bridge.
 * Registers listeners strictly while the UI is active (start/stop lifecycle)
 * and falls back safely to AudioManager media key events if notification listener
 * access has not been granted by the user. Zero background polling.
 */
class ActiveMediaManager(context: Context) {

    private val appContext = context.applicationContext
    private val mediaSessionManager =
        appContext.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
    private val audioManager =
        appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val _playbackState = MutableStateFlow(MediaPlaybackState())
    val playbackState: StateFlow<MediaPlaybackState> = _playbackState.asStateFlow()

    private var activeController: MediaController? = null
    private var isListening = false

    private val controllerCallback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) {
            publishFromController(activeController)
        }

        override fun onPlaybackStateChanged(state: PlaybackState?) {
            publishFromController(activeController)
        }
    }

    private val sessionsChangedListener =
        MediaSessionManager.OnActiveSessionsChangedListener { controllers ->
            attachPrimaryController(controllers.orEmpty())
        }

    fun startObserving() {
        if (isListening) return
        val hasAccess = isNotificationListenerEnabled()
        if (!hasAccess) {
            _playbackState.value = MediaPlaybackState(
                title = "System Media Controls Ready",
                artist = "Grant Notification Access for track title & artist",
                isPlaying = audioManager.isMusicActive,
                hasMetadataAccess = false
            )
            return
        }

        val listenerComponent = ComponentName(appContext, AutoHubNotificationListenerService::class.java)
        runCatching {
            val current = mediaSessionManager.getActiveSessions(listenerComponent)
            attachPrimaryController(current)
            mediaSessionManager.addOnActiveSessionsChangedListener(
                sessionsChangedListener,
                listenerComponent
            )
            isListening = true
        }.onFailure {
            _playbackState.value = MediaPlaybackState(
                title = "Media Controls Ready",
                artist = "Unable to inspect active session metadata",
                isPlaying = audioManager.isMusicActive,
                hasMetadataAccess = false
            )
        }
    }

    fun stopObserving() {
        if (isListening) {
            runCatching {
                mediaSessionManager.removeOnActiveSessionsChangedListener(sessionsChangedListener)
            }
            isListening = false
        }
        detachController()
    }

    fun togglePlayPause() {
        val controller = activeController
        if (controller != null) {
            val state = controller.playbackState?.state
            if (state == PlaybackState.STATE_PLAYING) {
                controller.transportControls.pause()
            } else {
                controller.transportControls.play()
            }
            return
        }
        dispatchMediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
        _playbackState.value = _playbackState.value.copy(
            isPlaying = !_playbackState.value.isPlaying
        )
    }

    fun skipNext() {
        val controller = activeController
        if (controller != null) {
            controller.transportControls.skipToNext()
        } else {
            dispatchMediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
        }
    }

    fun skipPrevious() {
        val controller = activeController
        if (controller != null) {
            controller.transportControls.skipToPrevious()
        } else {
            dispatchMediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
        }
    }

    fun isNotificationListenerEnabled(): Boolean {
        val enabledListeners = Settings.Secure.getString(
            appContext.contentResolver,
            "enabled_notification_listeners"
        ) ?: return false
        return enabledListeners.contains(appContext.packageName)
    }

    private fun attachPrimaryController(controllers: List<MediaController>) {
        val preferred = controllers.firstOrNull {
            it.playbackState?.state == PlaybackState.STATE_PLAYING
        } ?: controllers.firstOrNull()

        if (preferred?.sessionToken == activeController?.sessionToken) {
            publishFromController(preferred)
            return
        }

        detachController()
        activeController = preferred
        activeController?.registerCallback(controllerCallback)
        publishFromController(preferred)
    }

    private fun detachController() {
        activeController?.let {
            runCatching { it.unregisterCallback(controllerCallback) }
        }
        activeController = null
    }

    private fun publishFromController(controller: MediaController?) {
        if (controller == null) {
            _playbackState.value = MediaPlaybackState(
                title = "No Active Audio",
                artist = "Open Spotify, YouTube Music, or Podcasts",
                sourcePackage = null,
                isPlaying = false,
                hasMetadataAccess = true
            )
            return
        }

        val metadata = controller.metadata
        val title = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?.takeIf { it.isNotBlank() } ?: "Playing Media"
        val artist = metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?.takeIf { it.isNotBlank() }
            ?: metadata?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: controller.packageName
        val playing = controller.playbackState?.state == PlaybackState.STATE_PLAYING

        _playbackState.value = MediaPlaybackState(
            title = title,
            artist = artist,
            sourcePackage = controller.packageName,
            isPlaying = playing,
            hasMetadataAccess = true
        )
    }

    private fun dispatchMediaKey(keyCode: Int) {
        val now = SystemClock.uptimeMillis()
        val down = KeyEvent(now, now, KeyEvent.ACTION_DOWN, keyCode, 0)
        val up = KeyEvent(now, now, KeyEvent.ACTION_UP, keyCode, 0)
        audioManager.dispatchMediaKeyEvent(down)
        audioManager.dispatchMediaKeyEvent(up)
    }
}
