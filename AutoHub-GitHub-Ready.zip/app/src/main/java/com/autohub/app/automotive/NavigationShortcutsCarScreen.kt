package com.autohub.app.automotive

import android.content.Intent
import android.net.Uri
import androidx.car.app.CarContext
import androidx.car.app.CarToast
import androidx.car.app.HostException
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.ItemList
import androidx.car.app.model.ListTemplate
import androidx.car.app.model.Row
import androidx.car.app.model.Template
import com.autohub.app.R

/**
 * Official ListTemplate providing quick navigation handoffs via CarContext.ACTION_NAVIGATE.
 * Hands routing directly to the user's preferred Android Auto navigation app.
 */
class NavigationShortcutsCarScreen(carContext: CarContext) : Screen(carContext) {

    private data class QuickDestination(
        val title: String,
        val subtitle: String,
        val geoQuery: String
    )

    private val destinations = listOf(
        QuickDestination("EV Charging Station", "Find nearest fast charger", "geo:0,0?q=EV+charging+station"),
        QuickDestination("Fuel Station", "Find nearest gas station", "geo:0,0?q=gas+station"),
        QuickDestination("Parking Garage", "Find nearby parking", "geo:0,0?q=parking"),
        QuickDestination("Coffee & Rest Stop", "Quick break along route", "geo:0,0?q=coffee")
    )

    override fun onGetTemplate(): Template {
        val listBuilder = ItemList.Builder()

        destinations.forEach { dest ->
            listBuilder.addItem(
                Row.Builder()
                    .setTitle(dest.title)
                    .addText(dest.subtitle)
                    .setOnClickListener { startCarNavigation(dest.geoQuery, dest.title) }
                    .build()
            )
        }

        return ListTemplate.Builder()
            .setTitle(carContext.getString(R.string.car_nav_shortcuts_title))
            .setHeaderAction(Action.BACK)
            .setSingleList(listBuilder.build())
            .build()
    }

    private fun startCarNavigation(geoUri: String, label: String) {
        val navIntent = Intent(CarContext.ACTION_NAVIGATE, Uri.parse(geoUri))
        try {
            carContext.startCarApp(navIntent)
        } catch (_: HostException) {
            CarToast.makeText(
                carContext,
                "Unable to launch navigation for $label on this head unit.",
                CarToast.LENGTH_LONG
            ).show()
        }
    }
}
