package com.autohub.app.launcher

import androidx.compose.runtime.Immutable

@Immutable
data class InstalledApp(
    val packageName: String,
    val label: String,
    val isFavorite: Boolean
)
