package com.autohub.app.dashboard

import android.content.res.Configuration
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CloudDownload
import androidx.compose.material.icons.outlined.DirectionsCar
import androidx.compose.material.icons.outlined.EvStation
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.LocalGasStation
import androidx.compose.material.icons.outlined.Navigation
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.WorkOutline
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.autohub.app.data.AppIconCache
import com.autohub.app.launcher.InstalledApp
import com.autohub.app.ui.components.AutomotiveCard
import com.autohub.app.ui.theme.LocalAutoHubPalette

@Composable
fun DashboardScreen(
    uiState: DashboardUiState,
    iconCache: AppIconCache,
    onLoadWeather: () -> Unit,
    onNavigateQuery: (String) -> Unit,
    onPlayPause: () -> Unit,
    onSkipNext: () -> Unit,
    onSkipPrevious: () -> Unit,
    onLaunchApp: (String) -> Unit,
    onOpenLauncher: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE ||
        configuration.screenWidthDp >= 720

    if (isLandscape) {
        Row(
            modifier = modifier
                .fillMaxSize()
                .padding(20.dp),
            horizontalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Column(
                modifier = Modifier
                    .weight(1.05f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                ClockAndStatusCard(uiState = uiState, onOpenSettings = onOpenSettings)
                if (uiState.settings.showWeatherCard) {
                    WeatherCard(uiState = uiState, onLoadWeather = onLoadWeather)
                }
            }
            Column(
                modifier = Modifier
                    .weight(1.15f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                NavigationShortcutsCard(onNavigateQuery = onNavigateQuery)
                MusicControlCard(
                    uiState = uiState,
                    onPlayPause = onPlayPause,
                    onSkipNext = onSkipNext,
                    onSkipPrevious = onSkipPrevious
                )
                if (uiState.settings.showFavoritesStrip) {
                    FavoritesCard(
                        favorites = uiState.favoriteApps,
                        iconCache = iconCache,
                        onLaunchApp = onLaunchApp,
                        onOpenLauncher = onOpenLauncher
                    )
                }
            }
        }
    } else {
        Column(
            modifier = modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            ClockAndStatusCard(uiState = uiState, onOpenSettings = onOpenSettings)
            NavigationShortcutsCard(onNavigateQuery = onNavigateQuery)
            MusicControlCard(
                uiState = uiState,
                onPlayPause = onPlayPause,
                onSkipNext = onSkipNext,
                onSkipPrevious = onSkipPrevious
            )
            if (uiState.settings.showWeatherCard) {
                WeatherCard(uiState = uiState, onLoadWeather = onLoadWeather)
            }
            if (uiState.settings.showFavoritesStrip) {
                FavoritesCard(
                    favorites = uiState.favoriteApps,
                    iconCache = iconCache,
                    onLaunchApp = onLaunchApp,
                    onOpenLauncher = onOpenLauncher
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
private fun ClockAndStatusCard(
    uiState: DashboardUiState,
    onOpenSettings: () -> Unit
) {
    val palette = LocalAutoHubPalette.current
    AutomotiveCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Column {
                Text(
                    text = uiState.formattedTime,
                    style = MaterialTheme.typography.displayLarge,
                    color = palette.textPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = uiState.formattedDate,
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.textSecondary
                )
            }
            IconButton(onClick = onOpenSettings) {
                Icon(
                    imageVector = Icons.Outlined.Settings,
                    contentDescription = "Open Settings",
                    tint = palette.textSecondary
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Outlined.DirectionsCar,
                contentDescription = null,
                tint = palette.primaryAccent,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = uiState.vehicleStatus.label,
                style = MaterialTheme.typography.labelMedium,
                color = palette.textPrimary
            )
            Text(
                text = "·",
                style = MaterialTheme.typography.labelMedium,
                color = palette.textMuted
            )
            Text(
                text = if (uiState.isOnline) "Network Ready" else "Offline Mode",
                style = MaterialTheme.typography.labelMedium,
                color = if (uiState.isOnline) palette.positive else palette.textMuted
            )
        }
    }
}

@Composable
private fun WeatherCard(
    uiState: DashboardUiState,
    onLoadWeather: () -> Unit
) {
    val palette = LocalAutoHubPalette.current
    val weather = uiState.weather

    AutomotiveCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Weather · ${uiState.settings.weatherCity}",
                    style = MaterialTheme.typography.labelMedium,
                    color = palette.textMuted
                )
                Spacer(modifier = Modifier.height(6.dp))
                when {
                    weather.isLoading -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = palette.primaryAccent
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Fetching current conditions...",
                                style = MaterialTheme.typography.bodyMedium,
                                color = palette.textSecondary
                            )
                        }
                    }

                    weather.snapshot != null -> {
                        Text(
                            text = "${weather.snapshot.formattedTemperature(uiState.settings.useCelsius)} · ${weather.snapshot.conditionLabel}",
                            style = MaterialTheme.typography.headlineMedium,
                            color = palette.textPrimary
                        )
                        Text(
                            text = "Wind ${weather.snapshot.windKmh.toInt()} km/h · On-demand only",
                            style = MaterialTheme.typography.labelMedium,
                            color = palette.textMuted
                        )
                    }

                    else -> {
                        Text(
                            text = weather.errorMessage ?: "Not loaded (Zero background network usage)",
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (weather.errorMessage != null) palette.warning else palette.textSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Button(
                onClick = onLoadWeather,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = palette.surfaceElevated,
                    contentColor = palette.primaryAccent
                ),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.CloudDownload,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (weather.snapshot == null) "Load" else "Refresh",
                    style = MaterialTheme.typography.labelMedium
                )
            }
        }
    }
}

@Composable
private fun NavigationShortcutsCard(onNavigateQuery: (String) -> Unit) {
    val palette = LocalAutoHubPalette.current
    AutomotiveCard(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "Navigation Shortcuts",
            style = MaterialTheme.typography.labelMedium,
            color = palette.textMuted
        )
        Spacer(modifier = Modifier.height(12.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            NavShortcutTile(
                icon = Icons.Outlined.Home,
                label = "Home",
                modifier = Modifier.weight(1f),
                onClick = { onNavigateQuery("Home") }
            )
            NavShortcutTile(
                icon = Icons.Outlined.WorkOutline,
                label = "Work",
                modifier = Modifier.weight(1f),
                onClick = { onNavigateQuery("Work") }
            )
            NavShortcutTile(
                icon = Icons.Outlined.EvStation,
                label = "Charge",
                modifier = Modifier.weight(1f),
                onClick = { onNavigateQuery("EV charging station") }
            )
            NavShortcutTile(
                icon = Icons.Outlined.LocalGasStation,
                label = "Fuel",
                modifier = Modifier.weight(1f),
                onClick = { onNavigateQuery("Gas station") }
            )
        }
    }
}

@Composable
private fun NavShortcutTile(
    icon: ImageVector,
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val palette = LocalAutoHubPalette.current
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = palette.surfaceElevated
    ) {
        Column(
            modifier = Modifier.padding(vertical = 14.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = palette.primaryAccent,
                modifier = Modifier.size(22.dp)
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = palette.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun MusicControlCard(
    uiState: DashboardUiState,
    onPlayPause: () -> Unit,
    onSkipNext: () -> Unit,
    onSkipPrevious: () -> Unit
) {
    val palette = LocalAutoHubPalette.current
    val media = uiState.media

    AutomotiveCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Media Session",
                    style = MaterialTheme.typography.labelMedium,
                    color = palette.textMuted
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = media.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = media.artist,
                    style = MaterialTheme.typography.bodyMedium,
                    color = palette.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onSkipPrevious, modifier = Modifier.size(48.dp)) {
                    Icon(
                        imageVector = Icons.Rounded.SkipPrevious,
                        contentDescription = "Previous track",
                        tint = palette.textPrimary
                    )
                }
                Surface(
                    onClick = onPlayPause,
                    shape = RoundedCornerShape(14.dp),
                    color = palette.primaryAccent,
                    modifier = Modifier.size(50.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (media.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            contentDescription = if (media.isPlaying) "Pause" else "Play",
                            tint = palette.canvas
                        )
                    }
                }
                IconButton(onClick = onSkipNext, modifier = Modifier.size(48.dp)) {
                    Icon(
                        imageVector = Icons.Rounded.SkipNext,
                        contentDescription = "Next track",
                        tint = palette.textPrimary
                    )
                }
            }
        }
    }
}

@Composable
private fun FavoritesCard(
    favorites: List<InstalledApp>,
    iconCache: AppIconCache,
    onLaunchApp: (String) -> Unit,
    onOpenLauncher: () -> Unit
) {
    val palette = LocalAutoHubPalette.current
    val context = LocalContext.current

    AutomotiveCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Favorite Applications",
                style = MaterialTheme.typography.labelMedium,
                color = palette.textMuted
            )
            Text(
                text = "Manage",
                style = MaterialTheme.typography.labelMedium,
                color = palette.primaryAccent,
                modifier = Modifier.clickable(onClick = onOpenLauncher)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (favorites.isEmpty()) {
            Text(
                text = "Pin favorite apps from the Launcher for one-tap phone access.",
                style = MaterialTheme.typography.bodyMedium,
                color = palette.textSecondary
            )
        } else {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(items = favorites, key = { it.packageName }) { app ->
                    var bitmap by remember(app.packageName) {
                        mutableStateOf<ImageBitmap?>(iconCache.getIfCached(app.packageName))
                    }
                    LaunchedEffect(app.packageName) {
                        if (bitmap == null) {
                            bitmap = iconCache.loadOrGet(context.packageManager, app.packageName)
                        }
                    }

                    Column(
                        modifier = Modifier
                            .width(74.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .clickable { onLaunchApp(app.packageName) }
                            .padding(vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(palette.surfaceElevated),
                            contentAlignment = Alignment.Center
                        ) {
                            val bmp = bitmap
                            if (bmp != null) {
                                Image(bitmap = bmp, contentDescription = app.label, modifier = Modifier.size(34.dp))
                            } else {
                                Icon(Icons.Rounded.Apps, contentDescription = null, tint = palette.textMuted)
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = app.label,
                            style = MaterialTheme.typography.labelMedium,
                            color = palette.textPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}
