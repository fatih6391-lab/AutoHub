# AutoHub — Native Android & Android Auto Companion

AutoHub is a native Kotlin + Jetpack Compose Android application. It includes a phone dashboard/launcher and an Android Auto experience built with the official Android for Cars App Library.

## Automatic APK build (GitHub Actions)

This repository includes `.github/workflows/build-apk.yml` at the repository root. After the project files are pushed to the `main` or `master` branch, GitHub Actions automatically:

1. Sets up JDK 17, Android SDK Platform 35 and Gradle 8.10.2.
2. Runs `gradle clean assembleDebug`.
3. Verifies that the generated APK exists and is non-empty.
4. Copies the APK to `APK/AutoHub.apk`.
5. Creates `AutoHub-Full-Project.zip` containing the source and APK.
6. Verifies the APK inside the ZIP using SHA-256.
7. Publishes two downloadable workflow artifacts: `AutoHub-APK` and `AutoHub-Full-Project`.

To run manually, open the repository's **Actions** tab, select **Build AutoHub APK**, then choose **Run workflow**.

## Build locally

Requirements: JDK 17, Android SDK Platform 35, Android Build Tools 35.0.0, Gradle 8.10.2.

From this directory run:

```bash
gradle --no-daemon clean assembleDebug
```

Expected output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Application details

- Application ID: `com.autohub.app` (debug variant adds `.debug`)
- Minimum Android: 10 / API 29
- Compile SDK: 35
- Native Kotlin + Jetpack Compose + Material 3
- Official Android for Cars App Library integration

## Platform limitations

Android Auto does not allow third-party apps to replace its system launcher or freely display arbitrary phone apps. AutoHub uses supported car app templates and media APIs. YouTube/video playback is not projected onto Android Auto; the entertainment shortcut is for phone use while safely parked.

## Important

A successful GitHub Actions run is required before an APK exists. This source package itself is not an APK.
