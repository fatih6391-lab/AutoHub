package com.autohub.app

import com.autohub.app.data.WeatherRepository
import org.junit.Assert.assertEquals
import org.junit.Test

class WeatherParserTest {

    @Test
    fun parseOpenMeteoResponse_extractsTemperatureWindAndCondition() {
        val sampleJson = """
            {
              "current": {
                "temperature_2m": 18.6,
                "wind_speed_10m": 11.4,
                "weather_code": 2
              }
            }
        """.trimIndent()

        val snapshot = WeatherRepository.parseOpenMeteoResponse(
            city = "San Francisco",
            jsonBody = sampleJson,
            nowMs = 1_700_000_000_000L
        )

        assertEquals("San Francisco", snapshot.city)
        assertEquals(18.6, snapshot.temperatureCelsius, 0.01)
        assertEquals(11.4, snapshot.windKmh, 0.01)
        assertEquals("Partly Cloudy", snapshot.conditionLabel)
        assertEquals("19°C", snapshot.formattedTemperature(useCelsius = true))
        assertEquals("65°F", snapshot.formattedTemperature(useCelsius = false))
    }

    @Test
    fun mapWmoCodeToLabel_handlesRainAndClear() {
        assertEquals("Clear", WeatherRepository.mapWmoCodeToLabel(0))
        assertEquals("Rain", WeatherRepository.mapWmoCodeToLabel(63))
        assertEquals("Thunderstorm", WeatherRepository.mapWmoCodeToLabel(95))
    }
}
