package com.autohub.app.data

import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Memory-bounded LruCache for installed application icons.
 * Scales icons to 96x96px off the main thread to keep RAM usage low on entry-level hardware.
 */
class AppIconCache {

    private val maxCacheKilobytes: Int =
        ((Runtime.getRuntime().maxMemory() / 1024L) / 16L).toInt().coerceIn(2048, 12288)

    private val cache = object : LruCache<String, ImageBitmap>(maxCacheKilobytes) {
        override fun sizeOf(key: String, value: ImageBitmap): Int {
            // ARGB_8888 = 4 bytes per pixel -> kilobytes
            return (value.width * value.height * 4) / 1024
        }
    }

    fun getIfCached(packageName: String): ImageBitmap? = cache.get(packageName)

    suspend fun loadOrGet(
        packageManager: PackageManager,
        packageName: String,
        targetSizePx: Int = 96
    ): ImageBitmap? {
        cache.get(packageName)?.let { return it }

        return withContext(Dispatchers.IO) {
            runCatching {
                val drawable = packageManager.getApplicationIcon(packageName)
                val bitmap = drawableToScaledBitmap(drawable, targetSizePx)
                val imageBitmap = bitmap.asImageBitmap()
                cache.put(packageName, imageBitmap)
                imageBitmap
            }.getOrNull()
        }
    }

    fun clear() {
        cache.evictAll()
    }

    private fun drawableToScaledBitmap(drawable: Drawable, sizePx: Int): Bitmap {
        if (drawable is BitmapDrawable && drawable.bitmap != null) {
            val src = drawable.bitmap
            return if (src.width == sizePx && src.height == sizePx) {
                src
            } else {
                Bitmap.createScaledBitmap(src, sizePx, sizePx, true)
            }
        }
        val bitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return bitmap
    }
}
