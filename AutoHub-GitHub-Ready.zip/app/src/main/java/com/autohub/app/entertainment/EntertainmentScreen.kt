package com.autohub.app.entertainment

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.OpenInNew
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material.icons.outlined.Podcasts
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.autohub.app.R
import com.autohub.app.core.VehicleConnectionStatus
import com.autohub.app.ui.components.AutomotiveCard
import com.autohub.app.ui.theme.LocalAutoHubPalette

/**
 * Strictly separated, parked-only phone entertainment section.
 * Launches only the official YouTube application or https://m.youtube.com in the system browser.
 * Never downloads video streams, never bypasses DRM, and never projects video to Android Auto.
 */
@Composable
fun EntertainmentScreen(
    vehicleStatus: VehicleConnectionStatus,
    onOpenYouTube: (String?) -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalAutoHubPalette.current

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column {
            Text(
                text = "Parked Entertainment",
                style = MaterialTheme.typography.headlineMedium,
                color = palette.textPrimary
            )
            Text(
                text = "Phone display only · Never projected to Android Auto",
                style = MaterialTheme.typography.labelMedium,
                color = palette.textMuted
            )
        }

        AutomotiveCard(
            modifier = Modifier.fillMaxWidth(),
            borderColor = palette.warning.copy(alpha = 0.45f)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.Shield,
                    contentDescription = null,
                    tint = palette.warning,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = "Parked Use & Safety Compliance",
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.textPrimary
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = stringResource(id = R.string.parked_only_notice),
                style = MaterialTheme.typography.bodyMedium,
                color = palette.textSecondary
            )
            if (vehicleStatus == VehicleConnectionStatus.ANDROID_AUTO_PROJECTED) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Android Auto projection is currently active. Keep your focus on the road; " +
                        "open video apps on your phone only when safely parked.",
                    style = MaterialTheme.typography.labelMedium,
                    color = palette.warning
                )
            }
        }

        AutomotiveCard(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "Official YouTube Access",
                style = MaterialTheme.typography.titleMedium,
                color = palette.textPrimary
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Opens the official YouTube Android app if installed, or securely opens m.youtube.com in your default browser.",
                style = MaterialTheme.typography.bodyMedium,
                color = palette.textSecondary
            )
            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { onOpenYouTube(null) },
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = palette.primaryAccent,
                    contentColor = palette.canvas
                ),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Outlined.PlayCircle, contentDescription = null)
                Spacer(modifier = Modifier.size(8.dp))
                Text("Open Official YouTube")
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickChannelButton(
                    label = "Live News",
                    modifier = Modifier.weight(1f),
                    onClick = { onOpenYouTube("live news") }
                )
                QuickChannelButton(
                    label = "Podcasts",
                    modifier = Modifier.weight(1f),
                    onClick = { onOpenYouTube("video podcasts") }
                )
                QuickChannelButton(
                    label = "EV & Auto",
                    modifier = Modifier.weight(1f),
                    onClick = { onOpenYouTube("electric vehicle reviews") }
                )
            }
        }

        AutomotiveCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.Info,
                    contentDescription = null,
                    tint = palette.primaryAccent,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = "Android Auto vs. Android Automotive OS",
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.textPrimary
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Android Auto projects supported driving categories (Navigation, Media, Communication, POI) from your phone " +
                    "and prohibits video playback on the car display. Android Automotive OS (AAOS) is a separate in-vehicle operating " +
                    "system built directly into select cars where Google-certified parked video apps may run natively.",
                style = MaterialTheme.typography.bodyMedium,
                color = palette.textSecondary
            )
        }
    }
}

@Composable
private fun QuickChannelButton(
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val palette = LocalAutoHubPalette.current
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = palette.surfaceElevated
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (label == "Podcasts") Icons.Outlined.Podcasts else Icons.Outlined.OpenInNew,
                contentDescription = null,
                tint = palette.primaryAccent,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.size(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = palette.textPrimary,
                maxLines = 1
            )
        }
    }
}
