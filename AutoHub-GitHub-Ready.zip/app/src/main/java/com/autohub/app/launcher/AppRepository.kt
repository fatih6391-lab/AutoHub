package com.autohub.app.launcher

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Queries installed user-launchable applications respecting Android 11+ <queries> visibility.
 * Strictly used by the phone-side launcher interface; never used to launch arbitrary apps in Android Auto.
 */
class AppRepository(context: Context) {

    private val appContext = context.applicationContext
    private val packageManager: PackageManager = appContext.packageManager
    private val selfPackage = appContext.packageName

    suspend fun loadLaunchableApps(favoritePackages: Set<String>): List<InstalledApp> =
        withContext(Dispatchers.IO) {
            val launcherIntent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val resolveInfos = runCatching {
                packageManager.queryIntentActivities(launcherIntent, 0)
            }.getOrDefault(emptyList())

            resolveInfos
                .asSequence()
                .mapNotNull { info ->
                    val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
                    if (pkg == selfPackage) return@mapNotNull null
                    val label = info.loadLabel(packageManager)?.toString()?.trim()
                        ?.takeIf { it.isNotEmpty() } ?: pkg
                    InstalledApp(
                        packageName = pkg,
                        label = label,
                        isFavorite = pkg in favoritePackages
                    )
                }
                .distinctBy { it.packageName }
                .sortedWith(
                    compareByDescending<InstalledApp> { it.isFavorite }
                        .thenBy(String.CASE_INSENSITIVE_ORDER) { it.label }
                )
                .toList()
        }
}
