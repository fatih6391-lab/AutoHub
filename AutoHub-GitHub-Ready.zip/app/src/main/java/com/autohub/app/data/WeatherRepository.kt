package com.autohub.app.data

import com.autohub.app.core.AppResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

data class WeatherSnapshot(
    val city: String,
    val temperatureCelsius: Double,
    val windKmh: Double,
    val weatherCode: Int,
    val conditionLabel: String,
    val fetchedAtEpochMs: Long
) {
    fun formattedTemperature(useCelsius: Boolean): String {
        val value = if (useCelsius) temperatureCelsius else (temperatureCelsius * 9.0 / 5.0) + 32.0
        val unit = if (useCelsius) "°C" else "°F"
        return String.format(Locale.US, "%.0f%s", value, unit)
    }
}

/**
 * Zero-bloat, strictly on-demand WeatherRepository using JDK HttpURLConnection and Open-Meteo.
 * Never performs background polling; network requests fire only when the user explicitly asks.
 */
class WeatherRepository {

    @Volatile
    private var lastSnapshot: WeatherSnapshot? = null

    fun getCachedSnapshot(): WeatherSnapshot? = lastSnapshot

    suspend fun fetchOnDemand(
        city: String,
        latitude: Double,
        longitude: Double
    ): AppResult<WeatherSnapshot> = withContext(Dispatchers.IO) {
        var connection: HttpURLConnection? = null
        try {
            val endpoint = String.format(
                Locale.US,
                "https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f&current=temperature_2m,weather_code,wind_speed_10m",
                latitude,
                longitude
            )
            connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 5000
                readTimeout = 5000
                setRequestProperty("Accept", "application/json")
            }

            if (connection.responseCode !in 200..299) {
                return@withContext AppResult.Error("Weather service returned HTTP ${connection.responseCode}.")
            }

            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val parsed = parseOpenMeteoResponse(city, body, System.currentTimeMillis())
            lastSnapshot = parsed
            AppResult.Success(parsed)
        } catch (ex: Exception) {
            AppResult.Error("Weather unavailable. Check connection and retry.", ex)
        } finally {
            connection?.disconnect()
        }
    }

    companion object {
        fun parseOpenMeteoResponse(city: String, jsonBody: String, nowMs: Long): WeatherSnapshot {
            val root = JSONObject(jsonBody)
            val current = root.getJSONObject("current")
            val tempC = current.getDouble("temperature_2m")
            val wind = current.optDouble("wind_speed_10m", 0.0)
            val code = current.optInt("weather_code", 0)
            return WeatherSnapshot(
                city = city,
                temperatureCelsius = tempC,
                windKmh = wind,
                weatherCode = code,
                conditionLabel = mapWmoCodeToLabel(code),
                fetchedAtEpochMs = nowMs
            )
        }

        fun mapWmoCodeToLabel(code: Int): String = when (code) {
            0 -> "Clear"
            1, 2 -> "Partly Cloudy"
            3 -> "Overcast"
            45, 48 -> "Fog"
            51, 53, 55, 56, 57 -> "Drizzle"
            61, 63, 65, 66, 67 -> "Rain"
            71, 73, 75, 77 -> "Snow"
            80, 81, 82 -> "Showers"
            95, 96, 99 -> "Thunderstorm"
            else -> "Conditions"
        }
    }
}
