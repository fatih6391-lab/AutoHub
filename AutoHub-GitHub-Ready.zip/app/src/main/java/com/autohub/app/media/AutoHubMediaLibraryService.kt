package com.autohub.app.media

import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.SimpleBasePlayer
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.LibraryResult
import androidx.media3.session.MediaLibraryService
import androidx.media3.session.MediaSession
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture

/**
 * Official Media3 MediaLibraryService allowing Android Auto head units to browse
 * AutoHub's compliant audio categories without heavy background services.
 * Releases its MediaSession cleanly in onDestroy().
 */
@OptIn(UnstableApi::class)
class AutoHubMediaLibraryService : MediaLibraryService() {

    private var mediaLibrarySession: MediaLibrarySession? = null

    private val rootItem: MediaItem = MediaItem.Builder()
        .setMediaId(ROOT_ID)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle("AutoHub Audio")
                .setIsBrowsable(true)
                .setIsPlayable(false)
                .setMediaType(MediaMetadata.MEDIA_TYPE_FOLDER_MIXED)
                .build()
        )
        .build()

    private val quickAudioItems: ImmutableList<MediaItem> = ImmutableList.of(
        MediaItem.Builder()
            .setMediaId("station_ambient_drive")
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle("Driving Companion — Audio Ready")
                    .setArtist("Control your preferred audio player from AutoHub")
                    .setIsBrowsable(false)
                    .setIsPlayable(true)
                    .setMediaType(MediaMetadata.MEDIA_TYPE_MUSIC)
                    .build()
            )
            .build()
    )

    private val libraryCallback = object : MediaLibrarySession.Callback {
        override fun onGetLibraryRoot(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            params: LibraryParams?
        ): ListenableFuture<LibraryResult<MediaItem>> {
            return Futures.immediateFuture(LibraryResult.ofItem(rootItem, params))
        }

        override fun onGetChildren(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            parentId: String,
            page: Int,
            pageSize: Int,
            params: LibraryParams?
        ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> {
            val items = if (parentId == ROOT_ID) quickAudioItems else ImmutableList.of()
            return Futures.immediateFuture(LibraryResult.ofItemList(items, params))
        }
    }

    override fun onCreate() {
        super.onCreate()
        val lightweightPlayer = AutoHubStubPlayer(mainLooper)
        mediaLibrarySession = MediaLibrarySession.Builder(this, lightweightPlayer, libraryCallback)
            .setId("AutoHubMediaSession")
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaLibrarySession? {
        return mediaLibrarySession
    }

    override fun onDestroy() {
        mediaLibrarySession?.run {
            player.release()
            release()
        }
        mediaLibrarySession = null
        super.onDestroy()
    }

    /**
     * Minimal Media3 SimpleBasePlayer keeping RAM overhead tiny while maintaining
     * a valid MediaLibrarySession contract for Android Auto media discovery.
     */
    private class AutoHubStubPlayer(looper: android.os.Looper) : SimpleBasePlayer(looper) {
        private var currentPlayWhenReady = false

        override fun getState(): State {
            return State.Builder()
                .setAvailableCommands(
                    Player.Commands.Builder()
                        .add(Player.COMMAND_PLAY_PAUSE)
                        .add(Player.COMMAND_STOP)
                        .build()
                )
                .setPlayWhenReady(currentPlayWhenReady, PLAY_WHEN_READY_CHANGE_REASON_USER_REQUEST)
                .setPlaybackState(if (currentPlayWhenReady) STATE_READY else STATE_IDLE)
                .build()
        }

        override fun handleSetPlayWhenReady(playWhenReady: Boolean): ListenableFuture<*> {
            currentPlayWhenReady = playWhenReady
            invalidateState()
            return Futures.immediateVoidFuture()
        }
    }

    companion object {
        private const val ROOT_ID = "autohub_root"
    }
}
