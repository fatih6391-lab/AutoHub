package com.autohub.app.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.autohub.app.core.AppResult
import com.autohub.app.core.CarConnectionMonitor
import com.autohub.app.core.ConnectivityObserver
import com.autohub.app.core.VehicleConnectionStatus
import com.autohub.app.data.AutoHubPreferences
import com.autohub.app.data.UserSettings
import com.autohub.app.data.WeatherRepository
import com.autohub.app.data.WeatherSnapshot
import com.autohub.app.launcher.AppRepository
import com.autohub.app.launcher.InstalledApp
import com.autohub.app.media.ActiveMediaManager
import com.autohub.app.media.MediaPlaybackState
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class WeatherUiState(
    val snapshot: WeatherSnapshot? = null,
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)

data class DashboardUiState(
    val formattedTime: String = "--:--",
    val formattedDate: String = "",
    val isOnline: Boolean = false,
    val vehicleStatus: VehicleConnectionStatus = VehicleConnectionStatus.DISCONNECTED,
    val weather: WeatherUiState = WeatherUiState(),
    val media: MediaPlaybackState = MediaPlaybackState(),
    val favoriteApps: List<InstalledApp> = emptyList(),
    val settings: UserSettings = UserSettings()
)

class DashboardViewModel(
    private val preferences: AutoHubPreferences,
    private val weatherRepository: WeatherRepository,
    private val connectivityObserver: ConnectivityObserver,
    private val carConnectionMonitor: CarConnectionMonitor,
    private val appRepository: AppRepository,
    private val activeMediaManager: ActiveMediaManager
) : ViewModel() {

    private val weatherState = MutableStateFlow(
        WeatherUiState(snapshot = weatherRepository.getCachedSnapshot())
    )
    private val favoriteAppsFlow = MutableStateFlow<List<InstalledApp>>(emptyList())

    /**
     * Emits current timestamp aligned to minute boundaries to prevent unnecessary
     * per-second Jetpack Compose recompositions and minimize battery/CPU usage.
     */
    private val minuteClockFlow = flow {
        while (true) {
            val now = System.currentTimeMillis()
            emit(now)
            val delayToNextMinute = (60_000L - (now % 60_000L)).coerceAtLeast(1_000L)
            delay(delayToNextMinute)
        }
    }

    private val baseFlow = combine(
        minuteClockFlow,
        connectivityObserver.isOnlineFlow,
        carConnectionMonitor.connectionStatusFlow,
        preferences.settingsFlow
    ) { nowMs, isOnline, vehicleStatus, settings ->
        Quad(nowMs, isOnline, vehicleStatus, settings)
    }

    val uiState: StateFlow<DashboardUiState> = combine(
        baseFlow,
        weatherState,
        activeMediaManager.playbackState,
        favoriteAppsFlow
    ) { quad, weather, media, favorites ->
        val (nowMs, isOnline, vehicleStatus, settings) = quad
        val dateObj = Date(nowMs)
        val timePattern = if (settings.use24HourClock) "HH:mm" else "h:mm a"
        val timeText = SimpleDateFormat(timePattern, Locale.getDefault()).format(dateObj)
        val dateText = SimpleDateFormat("EEEE, MMM d", Locale.getDefault()).format(dateObj)

        DashboardUiState(
            formattedTime = timeText,
            formattedDate = dateText,
            isOnline = isOnline && !settings.offlineModeOnly,
            vehicleStatus = vehicleStatus,
            weather = weather,
            media = media,
            favoriteApps = favorites,
            settings = settings
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = DashboardUiState()
    )

    init {
        viewModelScope.launch {
            preferences.settingsFlow.collect { settings ->
                if (settings.favoritePackages.isEmpty()) {
                    favoriteAppsFlow.value = emptyList()
                } else {
                    val all = appRepository.loadLaunchableApps(settings.favoritePackages)
                    favoriteAppsFlow.value = all.filter { it.isFavorite }.take(8)
                }
            }
        }
    }

    /**
     * Loads weather strictly on explicit user tap. Respects offline mode setting
     * and connectivity status without silent retries or background polling.
     */
    fun loadWeatherOnDemand() {
        val currentSettings = uiState.value.settings
        if (currentSettings.offlineModeOnly) {
            weatherState.value = weatherState.value.copy(
                isLoading = false,
                errorMessage = "Offline-only mode is enabled in Settings."
            )
            return
        }
        if (!connectivityObserver.isCurrentlyOnline()) {
            weatherState.value = weatherState.value.copy(
                isLoading = false,
                errorMessage = "Device is offline. Dashboard remains fully functional."
            )
            return
        }

        viewModelScope.launch {
            weatherState.value = weatherState.value.copy(isLoading = true, errorMessage = null)
            when (
                val result = weatherRepository.fetchOnDemand(
                    city = currentSettings.weatherCity,
                    latitude = currentSettings.weatherLatitude,
                    longitude = currentSettings.weatherLongitude
                )
            ) {
                is AppResult.Success -> {
                    weatherState.value = WeatherUiState(
                        snapshot = result.data,
                        isLoading = false,
                        errorMessage = null
                    )
                }

                is AppResult.Error -> {
                    weatherState.value = weatherState.value.copy(
                        isLoading = false,
                        errorMessage = result.message
                    )
                }
            }
        }
    }

    fun togglePlayPause() = activeMediaManager.togglePlayPause()
    fun skipNext() = activeMediaManager.skipNext()
    fun skipPrevious() = activeMediaManager.skipPrevious()

    private data class Quad<A, B, C, D>(val a: A, val b: B, val c: C, val d: D)

    companion object {
        fun factory(
            preferences: AutoHubPreferences,
            weatherRepository: WeatherRepository,
            connectivityObserver: ConnectivityObserver,
            carConnectionMonitor: CarConnectionMonitor,
            appRepository: AppRepository,
            activeMediaManager: ActiveMediaManager
        ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return DashboardViewModel(
                    preferences = preferences,
                    weatherRepository = weatherRepository,
                    connectivityObserver = connectivityObserver,
                    carConnectionMonitor = carConnectionMonitor,
                    appRepository = appRepository,
                    activeMediaManager = activeMediaManager
                ) as T
            }
        }
    }
}
